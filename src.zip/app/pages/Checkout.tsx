import { motion, AnimatePresence } from "motion/react";
import { useState } from "react";
import { MapPin, Calendar, Router, CreditCard, CheckCircle2, ChevronRight, ChevronLeft, Wifi, Shield } from "lucide-react";
import { useNavigate } from "react-router";

export function Checkout() {
  const [step, setStep] = useState(1);
  const [date, setDate] = useState("");
  const [time, setTime] = useState("");
  const [mesh, setMesh] = useState(false);
  
  const navigate = useNavigate();

  const steps = [
    { num: 1, title: "Address", icon: <MapPin size={20} /> },
    { num: 2, title: "Installation", icon: <Calendar size={20} /> },
    { num: 3, title: "Equipment", icon: <Router size={20} /> },
    { num: 4, title: "Payment", icon: <CreditCard size={20} /> },
  ];

  const nextStep = () => {
    if (step === 4) {
      navigate("/order-success");
    } else {
      setStep((s) => Math.min(4, s + 1));
    }
  };
  const prevStep = () => setStep((s) => Math.max(1, s - 1));

  const planPrice = 35.00;
  const meshPrice = mesh ? 10.00 : 0;
  const total = planPrice + meshPrice;

  return (
    <div className="flex w-full bg-zinc-950 min-h-screen pt-32 pb-24 text-zinc-50 relative overflow-hidden">
      <div className="absolute top-0 right-0 w-[600px] h-[600px] bg-lime-400/10 rounded-full blur-[120px] pointer-events-none -z-10" />

      <div className="max-w-6xl mx-auto px-6 md:px-12 w-full z-10 flex flex-col lg:flex-row gap-8 items-start">
        
        <div className="w-full lg:w-2/3 flex flex-col">
            <div className="w-full mb-12">
              <div className="flex justify-between items-center relative mb-8">
                <div className="absolute left-0 right-0 top-1/2 -translate-y-1/2 h-1 bg-zinc-800 -z-10 rounded-full">
                  <motion.div 
                    className="h-full bg-lime-400 rounded-full"
                    initial={{ width: "0%" }}
                    animate={{ width: `${((step - 1) / (steps.length - 1)) * 100}%` }}
                    transition={{ duration: 0.3 }}
                  />
                </div>
                
                {steps.map((s) => (
                  <div key={s.num} className="flex flex-col items-center gap-2">
                    <div className={`w-10 h-10 rounded-full flex items-center justify-center font-bold transition-colors duration-300 ${step >= s.num ? "bg-lime-400 text-zinc-950" : "bg-zinc-900 border border-zinc-700 text-zinc-500"}`}>
                      {step > s.num ? <CheckCircle2 size={20} /> : s.icon}
                    </div>
                    <span className={`text-xs font-bold uppercase tracking-wide hidden sm:block ${step >= s.num ? "text-lime-400" : "text-zinc-600"}`}>
                      {s.title}
                    </span>
                  </div>
                ))}
              </div>
            </div>

          <div className="w-full bg-zinc-900 border border-zinc-800 rounded-3xl p-8 md:p-12 shadow-2xl relative overflow-hidden">
            <AnimatePresence mode="wait">
              {step === 1 && (
                <motion.div
                  key="step1"
                  initial={{ opacity: 0, x: 20 }}
                  animate={{ opacity: 1, x: 0 }}
                  exit={{ opacity: 0, x: -20 }}
                  className="flex flex-col gap-6"
                >
                  <h2 className="text-3xl font-black mb-2">Where are we connecting?</h2>
                  <p className="text-zinc-400 mb-4">We just need a few details to get your installation sorted.</p>
                  
                  <div className="space-y-4">
                    <div>
                      <label className="block text-sm font-bold text-zinc-500 mb-2 uppercase tracking-wide">Postcode</label>
                      <input type="text" className="w-full bg-zinc-950 border border-zinc-800 rounded-xl px-4 py-3 focus:outline-none focus:border-lime-400 focus:ring-1 focus:ring-lime-400 transition-all font-medium text-lg uppercase" placeholder="e.g. SW1A 1AA" />
                    </div>
                    <div>
                      <label className="block text-sm font-bold text-zinc-500 mb-2 uppercase tracking-wide">Address Line 1</label>
                      <input type="text" className="w-full bg-zinc-950 border border-zinc-800 rounded-xl px-4 py-3 focus:outline-none focus:border-lime-400 focus:ring-1 focus:ring-lime-400 transition-all font-medium" placeholder="123 Fibre Street" />
                    </div>
                    <div className="grid grid-cols-2 gap-4">
                      <div>
                        <label className="block text-sm font-bold text-zinc-500 mb-2 uppercase tracking-wide">City</label>
                        <input type="text" className="w-full bg-zinc-950 border border-zinc-800 rounded-xl px-4 py-3 focus:outline-none focus:border-lime-400 focus:ring-1 focus:ring-lime-400 transition-all font-medium" placeholder="London" />
                      </div>
                    </div>
                  </div>

                  <div className="mt-8 flex justify-end">
                    <button onClick={nextStep} className="bg-lime-400 hover:bg-lime-500 text-zinc-950 px-8 py-3 rounded-full font-black flex items-center gap-2 transition-transform active:scale-95">
                      Continue <ChevronRight size={20} />
                    </button>
                  </div>
                </motion.div>
              )}

              {step === 2 && (
                <motion.div
                  key="step2"
                  initial={{ opacity: 0, x: 20 }}
                  animate={{ opacity: 1, x: 0 }}
                  exit={{ opacity: 0, x: -20 }}
                  className="flex flex-col gap-6"
                >
                  <h2 className="text-3xl font-black mb-2">Schedule your visit</h2>
                  <p className="text-zinc-400 mb-4">Our engineers usually take about 1-2 hours to get you up and running.</p>
                  
                  <div className="space-y-6">
                    <div>
                      <label className="block text-sm font-bold text-zinc-500 mb-2 uppercase tracking-wide">Select Date</label>
                      <div className="relative">
                        <input 
                          type="date" 
                          value={date}
                          onChange={(e) => setDate(e.target.value)}
                          className="w-full bg-zinc-950 border border-zinc-800 rounded-xl px-4 py-3 focus:outline-none focus:border-lime-400 focus:ring-1 focus:ring-lime-400 transition-all font-medium text-zinc-50 [&::-webkit-calendar-picker-indicator]:filter [&::-webkit-calendar-picker-indicator]:invert" 
                        />
                      </div>
                    </div>

                    <div>
                      <label className="block text-sm font-bold text-zinc-500 mb-2 uppercase tracking-wide">Select Time</label>
                      <div className="relative">
                        <input 
                          type="time" 
                          value={time}
                          onChange={(e) => setTime(e.target.value)}
                          className="w-full bg-zinc-950 border border-zinc-800 rounded-xl px-4 py-3 focus:outline-none focus:border-lime-400 focus:ring-1 focus:ring-lime-400 transition-all font-medium text-zinc-50 [&::-webkit-calendar-picker-indicator]:filter [&::-webkit-calendar-picker-indicator]:invert" 
                        />
                      </div>
                      <p className="text-xs text-zinc-500 mt-2">Our engineers arrive between your chosen time and 2 hours after.</p>
                    </div>
                  </div>

                  <div className="mt-8 flex justify-between">
                    <button onClick={prevStep} className="text-zinc-400 hover:text-white px-4 py-3 rounded-full font-bold flex items-center gap-2 transition-colors">
                      <ChevronLeft size={20} /> Back
                    </button>
                    <button 
                      onClick={nextStep} 
                      disabled={!date || !time}
                      className="bg-lime-400 hover:bg-lime-500 disabled:opacity-50 disabled:cursor-not-allowed text-zinc-950 px-8 py-3 rounded-full font-black flex items-center gap-2 transition-transform active:scale-95"
                    >
                      Continue <ChevronRight size={20} />
                    </button>
                  </div>
                </motion.div>
              )}

              {step === 3 && (
                <motion.div
                  key="step3"
                  initial={{ opacity: 0, x: 20 }}
                  animate={{ opacity: 1, x: 0 }}
                  exit={{ opacity: 0, x: -20 }}
                  className="flex flex-col gap-6"
                >
                  <h2 className="text-3xl font-black mb-2">Choose your gear</h2>
                  <p className="text-zinc-400 mb-4">Every plan includes our standard Wi-Fi 6 router, but you can upgrade to our Pro Mesh system if you have a larger home.</p>
                  
                  <div className="space-y-4">
                    <label className={`relative flex p-6 rounded-2xl border-2 cursor-pointer transition-colors ${!mesh ? 'border-lime-400 bg-lime-400/5' : 'border-zinc-800 bg-zinc-950 hover:border-zinc-700'}`}>
                      <div className="flex items-center h-6">
                        <input 
                          name="router" 
                          type="radio" 
                          checked={!mesh} 
                          onChange={() => setMesh(false)}
                          className="w-5 h-5 text-lime-400 bg-zinc-900 border-zinc-700 focus:ring-lime-400 focus:ring-2" 
                        />
                      </div>
                      <div className="ml-4 flex flex-col">
                        <span className="font-black text-lg text-white">Standard Router</span>
                        <span className="text-zinc-400 text-sm mt-1">Included free. Great for apartments and smaller houses.</span>
                      </div>
                      <div className="ml-auto font-black text-lime-400 flex items-center">
                        Free
                      </div>
                    </label>

                    <label className={`relative flex p-6 rounded-2xl border-2 cursor-pointer transition-colors ${mesh ? 'border-lime-400 bg-lime-400/5' : 'border-zinc-800 bg-zinc-950 hover:border-zinc-700'}`}>
                      <div className="flex items-center h-6">
                        <input 
                          name="router" 
                          type="radio" 
                          checked={mesh}
                          onChange={() => setMesh(true)}
                          className="w-5 h-5 text-lime-400 bg-zinc-900 border-zinc-700 focus:ring-lime-400 focus:ring-2" 
                        />
                      </div>
                      <div className="ml-4 flex flex-col">
                        <span className="font-black text-lg text-white">Vean Pro Mesh System</span>
                        <span className="text-zinc-400 text-sm mt-1">2-node Wi-Fi 6E system. Eliminates dead zones in large homes.</span>
                      </div>
                      <div className="ml-auto font-black text-white flex flex-col items-end justify-center">
                        <span className={mesh ? "text-lime-400" : ""}>+£10</span>
                        <span className="text-xs text-zinc-500 font-bold">/month</span>
                      </div>
                    </label>
                  </div>

                  <div className="mt-8 flex justify-between">
                    <button onClick={prevStep} className="text-zinc-400 hover:text-white px-4 py-3 rounded-full font-bold flex items-center gap-2 transition-colors">
                      <ChevronLeft size={20} /> Back
                    </button>
                    <button onClick={nextStep} className="bg-lime-400 hover:bg-lime-500 text-zinc-950 px-8 py-3 rounded-full font-black flex items-center gap-2 transition-transform active:scale-95">
                      Continue to Payment <ChevronRight size={20} />
                    </button>
                  </div>
                </motion.div>
              )}

              {step === 4 && (
                <motion.div
                  key="step4"
                  initial={{ opacity: 0, x: 20 }}
                  animate={{ opacity: 1, x: 0 }}
                  exit={{ opacity: 0, x: -20 }}
                  className="flex flex-col gap-6"
                >
                  <h2 className="text-3xl font-black mb-2">Payment Details</h2>
                  <p className="text-zinc-400 mb-6">You won't be charged until your service is active and installed. We will use our API to process payments securely.</p>
                  
                  <div className="space-y-4">
                    <div>
                      <label className="block text-sm font-bold text-zinc-500 mb-2 uppercase tracking-wide">Name on Card</label>
                      <input type="text" className="w-full bg-zinc-950 border border-zinc-800 rounded-xl px-4 py-3 focus:outline-none focus:border-lime-400 focus:ring-1 focus:ring-lime-400 transition-all font-medium" placeholder="Jane Doe" />
                    </div>
                    <div>
                      <label className="block text-sm font-bold text-zinc-500 mb-2 uppercase tracking-wide">Card Number</label>
                      <div className="relative">
                        <input type="text" className="w-full bg-zinc-950 border border-zinc-800 rounded-xl pl-12 pr-4 py-3 focus:outline-none focus:border-lime-400 focus:ring-1 focus:ring-lime-400 transition-all font-medium font-mono" placeholder="0000 0000 0000 0000" />
                        <CreditCard className="absolute left-4 top-1/2 -translate-y-1/2 text-zinc-500" size={20} />
                      </div>
                    </div>
                    <div className="grid grid-cols-2 gap-4">
                      <div>
                        <label className="block text-sm font-bold text-zinc-500 mb-2 uppercase tracking-wide">Expiry</label>
                        <input type="text" className="w-full bg-zinc-950 border border-zinc-800 rounded-xl px-4 py-3 focus:outline-none focus:border-lime-400 focus:ring-1 focus:ring-lime-400 transition-all font-medium font-mono" placeholder="MM/YY" />
                      </div>
                      <div>
                        <label className="block text-sm font-bold text-zinc-500 mb-2 uppercase tracking-wide">CVC</label>
                        <input type="text" className="w-full bg-zinc-950 border border-zinc-800 rounded-xl px-4 py-3 focus:outline-none focus:border-lime-400 focus:ring-1 focus:ring-lime-400 transition-all font-medium font-mono" placeholder="123" />
                      </div>
                    </div>
                  </div>

                  <div className="mt-8 flex justify-between items-center">
                    <button onClick={prevStep} className="text-zinc-400 hover:text-white px-4 py-3 rounded-full font-bold flex items-center gap-2 transition-colors">
                      <ChevronLeft size={20} /> Back
                    </button>
                    <button onClick={nextStep} className="bg-lime-400 hover:bg-lime-500 text-zinc-950 px-8 py-4 rounded-full font-black flex items-center gap-2 transition-transform active:scale-95 text-lg">
                      Confirm Order
                    </button>
                  </div>
                </motion.div>
              )}
            </AnimatePresence>
          </div>
        </div>

        {/* Order Summary Sidebar */}
          <div className="w-full lg:w-1/3">
            <div className="bg-zinc-900 border border-zinc-800 rounded-3xl p-6 shadow-xl sticky top-32">
              <h3 className="text-xl font-black mb-6 flex items-center gap-2">
                Order Summary
              </h3>

              <div className="space-y-6">
                <div className="flex justify-between items-start border-b border-zinc-800 pb-6">
                  <div>
                    <div className="font-bold text-lg">Vean 500</div>
                    <div className="text-zinc-400 text-sm flex items-center gap-1 mt-1">
                      <Wifi size={14} /> 500 Mbps Average Speed
                    </div>
                  </div>
                  <div className="font-black text-lg">£{planPrice.toFixed(2)}</div>
                </div>

                <div className="space-y-3 border-b border-zinc-800 pb-6">
                  <div className="flex justify-between items-center text-sm">
                    <span className="text-zinc-400">Upfront installation</span>
                    <span className="font-bold text-lime-400">FREE</span>
                  </div>
                  <div className="flex justify-between items-center text-sm">
                    <span className="text-zinc-400">Standard Wi-Fi 6 Router</span>
                    <span className="font-bold">Included</span>
                  </div>
                  {mesh && (
                    <motion.div 
                      initial={{ opacity: 0, height: 0 }}
                      animate={{ opacity: 1, height: 'auto' }}
                      className="flex justify-between items-center text-sm"
                    >
                      <span className="text-zinc-400">Pro Mesh Upgrade</span>
                      <span className="font-bold">£{meshPrice.toFixed(2)}</span>
                    </motion.div>
                  )}
                  {date && time && (
                    <div className="flex justify-between items-start text-sm bg-zinc-950 p-3 rounded-lg border border-zinc-800 mt-2">
                      <span className="text-zinc-400">Install Visit</span>
                      <div className="text-right">
                        <div className="font-bold">{new Date(date).toLocaleDateString()}</div>
                        <div className="text-xs text-lime-400">{time}</div>
                      </div>
                    </div>
                  )}
                </div>

                <div className="flex justify-between items-center pt-2">
                  <span className="font-bold text-zinc-400">Monthly total</span>
                  <span className="text-3xl font-black text-white">£{total.toFixed(2)}</span>
                </div>

                <div className="bg-lime-400/10 border border-lime-400/20 rounded-xl p-4 flex gap-3 mt-4">
                  <Shield className="text-lime-400 shrink-0" size={20} />
                  <p className="text-xs text-lime-400/80 leading-relaxed">
                    Fixed price guarantee. Your monthly price won't increase during your contract term.
                  </p>
                </div>
              </div>
            </div>
          </div>

      </div>
    </div>
  );
}